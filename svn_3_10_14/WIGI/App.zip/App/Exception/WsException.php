<?php
class App_Exception_WsException extends Exception {

}
class App_Exception_FundsException extends Exception {

}

class App_Exception_CodeAlreadyRedeemedException extends Exception {

}

class App_Exception_CodeNotFoundException extends Exception {

}

class App_Exception_CodeTimedOutException extends Exception {

}
?>
